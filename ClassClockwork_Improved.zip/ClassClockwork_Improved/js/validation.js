/* Shared data validation for browser UI and Node tests. */
(function (root) {
  'use strict';
  const isNum = (v, min, max) => Number.isFinite(Number(v)) && Number(v) >= min && Number(v) <= max;
  function validate(data) {
    const errors = [];
    const add = (path, message) => errors.push({ path, message });
    if (!data || typeof data !== 'object') return [{ path: 'data', message: 'Dataset must be an object.' }];
    for (const key of ['batches', 'subjects', 'faculty', 'rooms']) {
      if (!Array.isArray(data[key])) add(key, `${key} must be an array.`);
    }
    if (errors.length) return errors;
    const collections = ['batches', 'subjects', 'faculty', 'rooms'];
    const maps = {};
    for (const key of collections) {
      maps[key] = new Map();
      data[key].forEach((item, i) => {
        const p = `${key}[${i}]`;
        if (!item || typeof item !== 'object') { add(p, 'Entry must be an object.'); return; }
        if (typeof item.id !== 'string' || !item.id.trim()) add(`${p}.id`, 'A non-empty ID is required.');
        else if (maps[key].has(item.id)) add(`${p}.id`, `Duplicate ID "${item.id}".`);
        else maps[key].set(item.id, item);
      });
    }
    data.batches.forEach((b, i) => {
      if (!String(b.name || '').trim()) add(`batches[${i}].name`, 'Batch name is required.');
      if (!isNum(b.size, 1, 10000)) add(`batches[${i}].size`, 'Student count must be between 1 and 10000.');
    });
    data.faculty.forEach((f, i) => {
      if (!String(f.name || '').trim()) add(`faculty[${i}].name`, 'Faculty name is required.');
      if (!isNum(f.maxLoad, 1, 40)) add(`faculty[${i}].maxLoad`, 'Weekly workload must be between 1 and 40 hours.');
      if (!Array.isArray(f.unavailable || [])) add(`faculty[${i}].unavailable`, 'Availability must be a list.');
      else (f.unavailable || []).forEach(slot => {
        if (!/^[0-4]-[0-5]$/.test(slot)) add(`faculty[${i}].unavailable`, `Invalid unavailable slot "${slot}".`);
      });
    });
    data.rooms.forEach((r, i) => {
      if (!String(r.name || '').trim()) add(`rooms[${i}].name`, 'Room name is required.');
      if (!isNum(r.capacity, 1, 10000)) add(`rooms[${i}].capacity`, 'Capacity must be between 1 and 10000.');
      if (!['classroom', 'lab'].includes(r.type)) add(`rooms[${i}].type`, 'Room type must be classroom or lab.');
      if (!Array.isArray(r.equipment || [])) add(`rooms[${i}].equipment`, 'Equipment must be a list.');
    });
    data.subjects.forEach((s, i) => {
      const p = `subjects[${i}]`;
      if (!String(s.code || '').trim() || !String(s.name || '').trim()) add(p, 'Subject code and name are required.');
      if (!isNum(s.lectureHours, 0, 30) || !Number.isInteger(Number(s.lectureHours))) add(`${p}.lectureHours`, 'Lecture hours must be a whole number from 0 to 30.');
      if (!isNum(s.labHours, 0, 6) || !Number.isInteger(Number(s.labHours))) add(`${p}.labHours`, 'Lab hours must be a whole number from 0 to 6.');
      if (Number(s.lectureHours || 0) + Number(s.labHours || 0) < 1) add(p, 'A subject must have at least one lecture or lab hour.');
      if (!maps.faculty.has(s.facultyId)) add(`${p}.facultyId`, 'Select an existing lecture faculty member.');
      if (s.labHours > 0 && s.labFacultyId && !maps.faculty.has(s.labFacultyId)) add(`${p}.labFacultyId`, 'Select an existing lab faculty member.');
      if (!Array.isArray(s.batchIds) || !s.batchIds.length) add(`${p}.batchIds`, 'Select at least one batch.');
      else s.batchIds.forEach(id => { if (!maps.batches.has(id)) add(`${p}.batchIds`, `Unknown batch reference "${id}".`); });
      if (!isNum(s.credits, 0, 30)) add(`${p}.credits`, 'Credits must be between 0 and 30.');
    });
    const st = data.settings || {};
    if (!Number.isInteger(Number(st.lunchAfter)) || ![2,3,4].includes(Number(st.lunchAfter))) add('settings.lunchAfter', 'Lunch must be after period 2, 3, or 4.');
    if (!isNum(st.maxPerDay, 1, 6)) add('settings.maxPerDay', 'Daily period limit must be between 1 and 6.');
    if (!isNum(st.maxConsecutive, 1, 6)) add('settings.maxConsecutive', 'Consecutive period limit must be between 1 and 6.');
    return errors;
  }
  const api = { validate };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  root.CCValidation = api;
})(typeof window !== 'undefined' ? window : globalThis);
