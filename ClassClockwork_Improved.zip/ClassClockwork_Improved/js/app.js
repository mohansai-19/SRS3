/* ClassClockwork UI: resource manager, timetable grid, drag & drop, auditor, exports. */
(function () {
  'use strict';
  const E = window.CCEngine, SAMPLES = window.CC_SAMPLES;
  const DAYS = E.DAYS, P = E.P;
  const LS_DATA = 'classclockwork.data.v1', LS_TT = 'classclockwork.timetable.v1';
  const $ = (s, r) => (r || document).querySelector(s);
  const $$ = (s, r) => [...(r || document).querySelectorAll(s)];
  const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const clone = o => JSON.parse(JSON.stringify(o));
  const byId = a => Object.fromEntries(a.map(x => [x.id, x]));

  const state = { data: null, tt: null, audit: [], badIds: new Set(), view: { mode: 'batch', id: null }, history: [], seed: 1, tab: 'resources', flash: null, movedId: null, stale: false, scope: 'view' };
  let drag = null;

  /* ================= persistence ================= */
  function nextMonday() {
    const d = new Date(); d.setDate(d.getDate() + ((8 - d.getDay()) % 7 || 7));
    return d.toISOString().slice(0, 10);
  }
  function loadSample(key) {
    state.data = clone(SAMPLES[key]); state.data.settings.semesterStart = nextMonday();
    state.tt = null; state.history = []; state.audit = []; state.stale = false; state.view = { mode: 'batch', id: null };
  }
  function save() {
    try { localStorage.setItem(LS_DATA, JSON.stringify(state.data)); localStorage.setItem(LS_TT, JSON.stringify(state.tt)); } catch (e) { /* storage may be unavailable */ }
  }
  function restore() {
    try {
      const d = JSON.parse(localStorage.getItem(LS_DATA) || 'null');
      if (d && window.CCValidation.validate(d).length === 0) {
        state.data = d;
        const t = JSON.parse(localStorage.getItem(LS_TT) || 'null');
        if (t && t.allocations) state.tt = t;
        return true;
      }
    } catch (e) { /* ignore corrupt storage */ }
    return false;
  }

  /* ================= helpers ================= */
  function toast(msg, kind) {
    const t = $('#toast'); t.textContent = msg; t.className = 'show ' + (kind || '');
    clearTimeout(toast.t); toast.t = setTimeout(() => { t.className = ''; }, kind === 'error' ? 5200 : 3200);
  }
  function hue(subjectId) { const i = state.data.subjects.findIndex(s => s.id === subjectId); return (Math.max(i, 0) * 47 + 205) % 360; }
  function nextId(prefix, arr) { let m = 0; arr.forEach(x => { const n = parseInt(String(x.id).replace(/\D/g, ''), 10); if (n > m) m = n; }); return prefix + (m + 1); }
  function recompute() {
    if (!state.tt) { state.audit = []; state.badIds = new Set(); return; }
    state.audit = E.audit(state.tt.allocations, state.tt.unallocated, state.data, { movedId: state.movedId });
    state.badIds = new Set(); state.audit.filter(v => v.sev === 'error').forEach(v => v.ids.forEach(i => state.badIds.add(i)));
  }
  function ensureView() {
    const d = state.data, m = state.view.mode;
    const list = m === 'batch' ? d.batches : m === 'faculty' ? d.faculty : d.rooms;
    if (!list.find(x => x.id === state.view.id)) state.view.id = list.length ? list[0].id : null;
  }
  function pushHistory() { state.history.push(JSON.stringify(state.tt)); if (state.history.length > 60) state.history.shift(); }

  /* ================= generate ================= */
  function generate(variant) {
    const d = state.data;
    if (!d.batches.length || !d.subjects.length || !d.rooms.length || !d.faculty.length) { toast('Add at least one batch, subject, faculty member and room first.', 'error'); return; }
    if (variant) state.seed++;
    const btn = $('#generateBtn'); btn.disabled = true; btn.textContent = 'Solving…';
    setTimeout(() => {
      const res = E.solve(d, { seed: state.seed });
      state.tt = res; state.history = []; state.stale = false; state.movedId = null; state.flash = null;
      recompute(); save(); ensureView();
      btn.disabled = false; btn.textContent = 'Generate timetable';
      switchTab('timetable');
      const un = res.unallocated.length, ms = res.stats.ms;
      if (!un) toast(`Conflict-free timetable: ${res.stats.placed}/${res.stats.total} classes placed in ${ms} ms (${res.stats.mode} mode).`, 'ok');
      else toast(`${res.stats.placed}/${res.stats.total} classes placed in ${ms} ms. ${un} unallocated — see the tray below the grid.`, 'error');
    }, 30);
  }

  /* ================= tabs ================= */
  function switchTab(t) {
    state.tab = t;
    $$('.tab').forEach(b => b.classList.toggle('active', b.dataset.tab === t));
    $$('.tabpane').forEach(p => p.classList.toggle('active', p.id === 'tab-' + t));
    if (t === 'timetable') renderTimetable(); else renderResources();
    $('#undoBtn').disabled = !state.history.length;
  }

  /* ================= resources tab ================= */
  function renderResources() {
    const d = state.data, F = byId(d.faculty), B = byId(d.batches), s = d.settings;
    const batchName = id => (B[id] ? B[id].name : '?');
    const diag = E.diagnose(d);
    const tbl = (cols, rows, kind, empty) => rows.length ? `<table class="list"><thead><tr>${cols.map(c => `<th>${c}</th>`).join('')}<th></th></tr></thead><tbody>${rows.map(r => `<tr>${r.cells.map(c => `<td>${c}</td>`).join('')}<td class="act"><button class="btn small" data-act="edit" data-kind="${kind}" data-id="${r.id}">Edit</button> <button class="btn small danger" data-act="del" data-kind="${kind}" data-id="${r.id}">Delete</button></td></tr>`).join('')}</tbody></table>` : `<div class="empty">${empty}</div>`;
    const head = (title, sub, kind) => `<header><h2>${title}<small>${sub}</small></h2><button class="btn small blue" data-act="add" data-kind="${kind}">+ Add</button></header>`;

    $('#tab-resources').innerHTML = `
    <div class="res-layout"><div>
      <div class="panel"><header><h2>Schedule rules</h2></header><div class="body"><div class="settings-grid">
        <label class="f">Lunch break after period<select data-set="lunchAfter">${[2, 3, 4].map(n => `<option value="${n}" ${+s.lunchAfter === n ? 'selected' : ''}>P${n} (all batches)</option>`).join('')}</select></label>
        <label class="f">Max periods per batch per day<input type="number" min="3" max="6" data-set="maxPerDay" value="${esc(s.maxPerDay)}"></label>
        <label class="f">Max back-to-back lecture periods<input type="number" min="1" max="6" data-set="maxConsecutive" value="${esc(s.maxConsecutive)}"></label>
        <label class="f">Semester start (for .ics)<input type="date" data-set="semesterStart" value="${esc(s.semesterStart)}"></label>
        <label class="f">Weeks (for .ics)<input type="number" min="1" max="30" data-set="weeks" value="${esc(s.weeks)}"></label>
      </div></div></div>

      <div class="panel">${head('Student batches', d.batches.length + ' batches', 'batch')}
        ${tbl(['Batch', 'Strength'], d.batches.map(b => ({ id: b.id, cells: [`<b>${esc(b.name)}</b>`, b.size] })), 'batch', 'No batches yet.')}</div>

      <div class="panel">${head('Subjects', d.subjects.length + ' subjects', 'subject')}
        ${tbl(['Subject', 'Credits', 'Lecture h', 'Lab h', 'Faculty', 'Batches'], d.subjects.map(x => ({ id: x.id, cells: [
          `<span class="swatch" style="background:hsl(${hue(x.id)} 62% 44%)"></span><b>${esc(x.code)}</b> ${esc(x.name)}`, x.credits, x.lectureHours,
          x.labHours > 0 ? `<span class="chip lab">${x.labHours} h block${x.labEquipment ? ' · ' + esc(x.labEquipment) : ''}</span>` : '–',
          esc((F[x.facultyId] || {}).name || '—') + (x.labHours > 0 && x.labFacultyId && x.labFacultyId !== x.facultyId ? `<br><small class="hint">Lab: ${esc((F[x.labFacultyId] || {}).name || '—')}</small>` : ''),
          (x.batchIds || []).map(id => `<span class="chip">${esc(batchName(id))}</span>`).join('')] })), 'subject', 'No subjects yet.')}</div>

      <div class="panel">${head('Faculty', d.faculty.length + ' members', 'faculty')}
        ${tbl(['Name', 'Max h/week', 'Preference', 'Blocked slots'], d.faculty.map(f => ({ id: f.id, cells: [`<b>${esc(f.name)}</b>`, f.maxLoad,
          f.preference === 'none' || !f.preference ? '–' : `<span class="chip pref">${esc(f.preference)}</span>`, (f.unavailable || []).length ? (f.unavailable.length + ' of 30') : 'None'] })), 'faculty', 'No faculty yet.')}</div>

      <div class="panel">${head('Classrooms & labs', d.rooms.length + ' rooms', 'room')}
        ${tbl(['Room', 'Type', 'Seats', 'Equipment'], d.rooms.map(r => ({ id: r.id, cells: [`<b>${esc(r.name)}</b>`, r.type === 'lab' ? '<span class="chip lab">Lab</span>' : 'Classroom', r.capacity, (r.equipment || []).map(e => `<span class="chip">${esc(e)}</span>`).join('') || '–'] })), 'room', 'No rooms yet.')}</div>
    </div>
    <aside class="side">
      <div class="panel"><header><h2>Pre-flight check</h2></header><ul class="diag">${diag.map(x => `<li><span class="dot ${x.sev}"></span><span>${esc(x.msg)}</span></li>`).join('')}</ul></div>
      <div class="panel"><header><h2>Data</h2></header><div class="body" style="display:grid;gap:8px">
        <button class="btn" data-act="export-json">Export data + timetable (.json)</button>
        <button class="btn" data-act="import-json">Import .json</button>
        <button class="btn danger" data-act="reset">Clear everything</button>
        <span class="hint">Everything is saved automatically in this browser (localStorage).</span></div></div>
    </aside></div>`;
  }

  /* ---------- forms ---------- */
  const FORMS = {
    batch: { title: 'Batch', fields: [
      { k: 'name', l: 'Batch name', t: 'text', req: 1 },
      { k: 'size', l: 'Strength (students)', t: 'number', min: 1, req: 1 }] },
    subject: { title: 'Subject', fields: [
      { k: 'code', l: 'Subject code', t: 'text', req: 1 },
      { k: 'name', l: 'Subject name', t: 'text', req: 1 },
      { k: 'credits', l: 'Credits', t: 'number', min: 0 },
      { k: 'lectureHours', l: 'Lecture hours / week (1 period each)', t: 'number', min: 0, max: 10 },
      { k: 'labHours', l: 'Lab hours / week (one continuous block, 0 = none)', t: 'number', min: 0, max: 3 },
      { k: 'facultyId', l: 'Lecture faculty', t: 'select', opts: d => d.faculty.map(f => [f.id, f.name]), req: 1 },
      { k: 'labFacultyId', l: 'Lab faculty (optional)', t: 'select', opts: d => [['', 'Same as lecture faculty']].concat(d.faculty.map(f => [f.id, f.name])) },
      { k: 'labEquipment', l: 'Required lab equipment (optional, e.g. Linux)', t: 'text' },
      { k: 'batchIds', l: 'Taught to batches', t: 'multi', opts: d => d.batches.map(b => [b.id, b.name]) }] },
    faculty: { title: 'Faculty member', fields: [
      { k: 'name', l: 'Name', t: 'text', req: 1 },
      { k: 'maxLoad', l: 'Workload limit (hours / week)', t: 'number', min: 1, max: 30, req: 1 },
      { k: 'preference', l: 'Preferred teaching time (soft)', t: 'select', opts: () => [['none', 'No preference'], ['morning', 'Morning'], ['afternoon', 'Afternoon']] },
      { k: 'unavailable', l: 'Availability — click a slot to block it', t: 'avail' }] },
    room: { title: 'Room', fields: [
      { k: 'name', l: 'Room name', t: 'text', req: 1 },
      { k: 'type', l: 'Type', t: 'select', opts: () => [['classroom', 'Classroom'], ['lab', 'Laboratory']] },
      { k: 'capacity', l: 'Seating capacity', t: 'number', min: 1, req: 1 },
      { k: 'equipment', l: 'Equipment (comma separated)', t: 'text' }] }
  };
  const COLL = { batch: 'batches', subject: 'subjects', faculty: 'faculty', room: 'rooms' };
  const PREFIX = { batch: 'b', subject: 's', faculty: 'f', room: 'r' };

  function defaultsFor(kind) {
    const d = state.data;
    return ({
      batch: { name: '', size: 60 },
      subject: { code: '', name: '', credits: 3, lectureHours: 3, labHours: 0, facultyId: (d.faculty[0] || {}).id || '', labFacultyId: '', labEquipment: '', batchIds: d.batches.map(b => b.id) },
      faculty: { name: '', maxLoad: 12, preference: 'none', unavailable: [] },
      room: { name: '', type: 'classroom', capacity: 60, equipment: [] }
    })[kind];
  }

  function openForm(kind, id) {
    const d = state.data, cfg = FORMS[kind], coll = d[COLL[kind]];
    const rec = id ? clone(coll.find(x => x.id === id)) : defaultsFor(kind);
    if (kind === 'room') rec.equipment = (rec.equipment || []).join(', ');
    const fieldHtml = f => {
      const v = rec[f.k];
      if (f.t === 'select') return `<label class="f">${f.l}<select name="${f.k}">${f.opts(d).map(o => `<option value="${esc(o[0])}" ${String(o[0]) === String(v) ? 'selected' : ''}>${esc(o[1])}</option>`).join('')}</select></label>`;
      if (f.t === 'multi') return `<div class="f">${f.l}<div class="checks">${f.opts(d).map(o => `<label><input type="checkbox" name="${f.k}" value="${esc(o[0])}" ${(v || []).includes(o[0]) ? 'checked' : ''}>${esc(o[1])}</label>`).join('') || '<span class="hint">Add a batch first.</span>'}</div></div>`;
      if (f.t === 'avail') {
        const un = new Set(v || []);
        return `<div class="f">${f.l}<table class="avail"><tr><th></th>${DAYS.map(x => `<th>${x}</th>`).join('')}</tr>${[0, 1, 2, 3, 4, 5].map(p => `<tr><th>P${p + 1}</th>${DAYS.map((x, di) => `<td><button type="button" data-slot="${di}-${p}" class="${un.has(di + '-' + p) ? 'off' : ''}">${un.has(di + '-' + p) ? '✕' : ''}</button></td>`).join('')}</tr>`).join('')}</table><span class="hint">Red = faculty cannot teach in that period.</span></div>`;
      }
      return `<label class="f">${f.l}<input name="${f.k}" type="${f.t}" value="${esc(v)}" ${f.min != null ? `min="${f.min}"` : ''} ${f.max != null ? `max="${f.max}"` : ''} ${f.req ? 'required' : ''}></label>`;
    };
    const m = $('#modal');
    m.innerHTML = `<form><div class="mh">${id ? 'Edit' : 'Add'} ${cfg.title.toLowerCase()}</div><div class="mb">${cfg.fields.map(fieldHtml).join('')}</div>
      <div class="mf"><button type="button" class="btn" data-close>Cancel</button><button type="submit" class="btn primary">Save ${cfg.title.toLowerCase()}</button></div></form>`;
    $$('table.avail button', m).forEach(b => b.addEventListener('click', () => { b.classList.toggle('off'); b.textContent = b.classList.contains('off') ? '✕' : ''; }));
    $('[data-close]', m).addEventListener('click', () => m.close());
    $('form', m).addEventListener('submit', ev => {
      ev.preventDefault();
      const out = id ? clone(coll.find(x => x.id === id)) : { id: nextId(PREFIX[kind], coll) };
      for (const f of cfg.fields) {
        if (f.t === 'multi') out[f.k] = $$(`input[name="${f.k}"]:checked`, m).map(i => i.value);
        else if (f.t === 'avail') out[f.k] = $$('table.avail button.off', m).map(b => b.dataset.slot);
        else { const el = $(`[name="${f.k}"]`, m); out[f.k] = f.t === 'number' ? Number(el.value) : el.value.trim(); }
      }
      if (kind === 'room') out.equipment = String(out.equipment).split(',').map(x => x.trim()).filter(Boolean);
      const candidate = clone(state.data);
      const candidateList = candidate[COLL[kind]];
      if (id) candidate[COLL[kind]] = candidateList.map(x => x.id === id ? out : x);
      else candidateList.push(out);
      const issues = window.CCValidation.validate(candidate);
      if (issues.length) { toast(issues.slice(0, 3).map(x => x.message).join(' '), 'error'); return; }
      if (id) { const index = coll.findIndex(x => x.id === id); coll[index] = out; } else coll.push(out);
      if (kind === 'subject' && state.tt) syncSubjectFaculty(out);
      afterEdit(); m.close();
    });
    m.showModal();
  }
  function syncSubjectFaculty(s) {
    state.tt.allocations.forEach(a => { if (a.subjectId === s.id) a.facultyId = a.type === 'lab' ? (s.labFacultyId || s.facultyId) : s.facultyId; });
  }
  function afterEdit() {
    if (state.tt) state.stale = true;
    recompute(); save(); renderResources();
  }
  function deleteItem(kind, id) {
    const d = state.data, coll = d[COLL[kind]];
    const rec = coll.find(x => x.id === id); if (!rec) return;
    let used = 0;
    if (kind === 'faculty') used = d.subjects.filter(s => s.facultyId === id || s.labFacultyId === id).length;
    if (kind === 'batch') used = d.subjects.filter(s => (s.batchIds || []).includes(id)).length;
    if (used && kind === 'faculty') { toast(`${rec.name} still teaches ${used} subject(s). Reassign those subjects first.`, 'error'); return; }
    const msg = `Delete ${rec.name || rec.code}?` + (state.tt ? ' The generated timetable will be cleared because it refers to this item.' : '');
    if (!confirm(msg)) return;
    d[COLL[kind]] = coll.filter(x => x.id !== id);
    if (kind === 'batch') d.subjects.forEach(s => { s.batchIds = (s.batchIds || []).filter(b => b !== id); });
    if (kind !== 'subject' || state.tt) { /* any deletion invalidates the timetable */ }
    state.tt = null; state.history = []; state.stale = false; recompute(); save(); renderResources();
  }

  /* ================= timetable tab ================= */
  function entityList() { const d = state.data, m = state.view.mode; return m === 'batch' ? d.batches : m === 'faculty' ? d.faculty : d.rooms; }
  function gridHtml(mode, id, interactive) {
    const d = state.data, L = +d.settings.lunchAfter, T = E.periodTimes(L);
    const S = byId(d.subjects), F = byId(d.faculty), B = byId(d.batches), R = byId(d.rooms);
    const allocs = state.tt.allocations.filter(a => (mode === 'batch' ? a.batchId : mode === 'faculty' ? a.facultyId : a.roomId) === id);
    const nm = (m, k) => (m[k] ? m[k].name : '?');
    const cell = (day, p) => allocs.filter(a => a.day === day && p >= a.start && p < a.start + a.dur).map(a => {
      const s = S[a.subjectId] || { code: '?', name: '?' }, off = p - a.start, bad = state.badIds.has(a.id);
      const lab = a.type === 'lab' ? '<i class="tag">LAB</i>' : '';
      let inner;
      if (off > 0) inner = `↳ ${esc(s.code)} lab continues`;
      else if (mode === 'batch') inner = `<b>${esc(s.code)}</b>${lab}<span class="nm">${esc(s.name)}</span><small>${esc(nm(F, a.facultyId))} · ${esc(nm(R, a.roomId))}</small>`;
      else if (mode === 'faculty') inner = `<b>${esc(s.code)}</b>${lab}<span class="nm">${esc(nm(B, a.batchId))}</span><small>${esc(nm(R, a.roomId))}</small>`;
      else inner = `<b>${esc(s.code)}</b>${lab}<span class="nm">${esc(nm(B, a.batchId))}</span><small>${esc(nm(F, a.facultyId))}</small>`;
      const flash = interactive && state.flash === a.id ? ' flash' : '';
      return `<div class="card ${a.type}${off > 0 ? ' cont' : ''}${bad ? ' bad' : ''}${flash}" style="--h:${hue(a.subjectId)}" ${interactive ? `draggable="true" data-id="${esc(a.id)}" data-off="${off}"` : ''}>${inner}${bad && off === 0 ? '<span class="badge">⚠ Clash</span>' : ''}</div>`;
    }).join('');
    let rows = '';
    for (let p = 0; p < P; p++) {
      if (p === L && T.lunch) rows += `<tr class="lunch"><th>${T.lunch.s}–${T.lunch.e}</th><td colspan="5">Lunch break</td></tr>`;
      rows += `<tr><th class="time"><b>P${p + 1}</b><span>${T.slots[p].s}–${T.slots[p].e}</span></th>${DAYS.map((x, di) => `<td data-d="${di}" data-p="${p}">${cell(di, p)}</td>`).join('')}</tr>`;
    }
    return `<table class="grid"><thead><tr><th class="corner"></th>${DAYS.map(x => `<th>${x}</th>`).join('')}</tr></thead><tbody>${rows}</tbody></table>`;
  }

  function renderTimetable() {
    const root = $('#tab-timetable');
    if (!state.tt) {
      root.innerHTML = `<div class="hero"><h2>No timetable yet</h2><p>Check the Resources tab, then generate a conflict-free weekly grid. The solver places labs first, then lectures, and flags anything it can't fit instead of freezing.</p><button class="btn primary" data-act="generate">Generate timetable</button></div>`;
      return;
    }
    ensureView();
    const d = state.data, v = state.view, list = entityList();
    const errs = state.audit.filter(x => x.sev === 'error').length, warns = state.audit.filter(x => x.sev === 'warn').length;
    const loads = E.facultyLoads(state.tt.allocations, d), vals = d.faculty.map(f => loads[f.id] || 0), g = E.gini(vals);
    const gLabel = g < 0.15 ? 'Well balanced' : g < 0.3 ? 'Moderately uneven' : 'Uneven';
    const stats = state.tt.stats;
    const un = state.tt.unallocated;
    const S = byId(d.subjects), B = byId(d.batches);

    root.innerHTML = `
    ${state.stale ? `<div class="banner"><span>Resources changed since this timetable was generated. The auditor is checking the current grid against the new data.</span><button class="btn small primary" data-act="generate">Regenerate</button></div>` : ''}
    <div class="toolbar">
      <div class="seg" role="group" aria-label="View">${['batch', 'faculty', 'room'].map(m => `<button data-view="${m}" class="${v.mode === m ? 'on' : ''}">${m === 'batch' ? 'Batch' : m === 'faculty' ? 'Faculty' : 'Room'}</button>`).join('')}</div>
      <select id="entitySel" aria-label="Select ${v.mode}">${list.map(x => `<option value="${x.id}" ${x.id === v.id ? 'selected' : ''}>${esc(x.name)}</option>`).join('')}</select>
      <div class="sp">
        <button class="btn" data-act="regen">Another variant</button>
        <select id="scopeSel" aria-label="Export scope"><option value="view">Current view</option><option value="batch">All batches</option><option value="faculty">All faculty</option><option value="room">All rooms</option></select>
        <button class="btn" data-act="pdf">Export PDF / print</button>
        <button class="btn" data-act="ics">Export .ics</button>
      </div>
    </div>
    <div class="tt-layout"><div>
      <div class="gridwrap" id="gridWrap">${v.id ? gridHtml(v.mode, v.id, true) : '<div class="empty">Nothing to show.</div>'}</div>
      ${un.length ? `<div class="tray"><h3>Unallocated (${un.length}) — drag onto the grid to place manually</h3><div class="items">${un.map(u => `<div class="item" draggable="true" data-un="${esc(u.id)}"><b>${esc((S[u.subjectId] || {}).code)}</b> ${esc((B[u.batchId] || {}).name)} ${u.type === 'lab' ? u.dur + 'h lab' : 'lecture'}<small>${esc(u.reason)}</small></div>`).join('')}</div></div>` : ''}
    </div>
    <aside class="side">
      <div class="panel"><header><h2>Clash auditor${errs ? `<span class="count error">${errs}</span>` : ''}${warns ? `<span class="count warn">${warns}</span>` : ''}${!errs && !warns ? '<span class="count ok">clear</span>' : ''}</h2></header>
        <ul class="viol">${state.audit.length ? state.audit.map(x => `<li data-ids="${esc(x.ids.join(','))}"><span class="dot ${x.sev}"></span><span>${esc(x.msg)}</span></li>`).join('') : '<li><span class="dot ok"></span><span>No rule violations. Drag a class onto a busy slot to see a live clash.</span></li>'}</ul></div>
      <div class="panel"><header><h2>Faculty workload</h2></header><div class="body">
        <div class="gini"><b>${g.toFixed(2)}</b><span>Gini coefficient · ${gLabel}<br>0 = everyone teaches equally</span></div>
        ${d.faculty.map(f => { const h = loads[f.id] || 0, max = +f.maxLoad || 1; return `<div class="bar"><span class="nm" title="${esc(f.name)}">${esc(f.name)}</span><span class="track"><span class="fill ${h > max ? 'over' : ''}" style="width:${Math.min(100, h / max * 100)}%"></span></span><span>${h}/${max}h</span></div>`; }).join('')}
      </div></div>
      <div class="panel"><header><h2>Solver run</h2></header><div class="body">
        <div class="kv"><span>Classes placed</span><b>${stats.placed} / ${stats.total}</b></div>
        <div class="kv"><span>Time</span><b>${stats.ms} ms</b></div>
        <div class="kv"><span>Search nodes</span><b>${stats.nodes}</b></div>
        <div class="kv"><span>Variant seed</span><b>${stats.seed}</b></div>
        ${stats.attempts.map(a => `<div class="attempt"><span>${esc(a.name)} <small class="hint">${esc(a.note || '')}</small></span><span class="${a.ok ? 'ok' : 'no'}">${a.ok ? 'solved' : 'not solved'}</span></div>`).join('')}
      </div></div>
    </aside></div>`;
    $('#scopeSel').value = state.scope;
    $('#undoBtn').disabled = !state.history.length;
    if (state.flash) setTimeout(() => { state.flash = null; }, 2500);
  }

  /* ---------- drag & drop ---------- */
  function simulateErrors(a, day, start) {
    const sim = state.tt.allocations.map(x => (x.id === a.id ? Object.assign({}, x, { day, start }) : x));
    return E.audit(sim, [], state.data, { movedId: a.id }).filter(v => v.sev === 'error' && v.ids.includes(a.id)).length;
  }
  function clearHints() { $$('#gridWrap td').forEach(td => td.classList.remove('drop-ok', 'drop-bad', 'drop-over')); $$('.card.dragging').forEach(c => c.classList.remove('dragging')); }
  function onDragStart(e) {
    const card = e.target.closest('.card[data-id]'), item = e.target.closest('.item[data-un]');
    if (!card && !item) return;
    if (card) {
      const a = state.tt.allocations.find(x => x.id === card.dataset.id); if (!a) return;
      drag = { kind: 'alloc', id: a.id, off: +card.dataset.off, a };
      $$(`.card[data-id="${CSS.escape(a.id)}"]`).forEach(c => c.classList.add('dragging'));
    } else {
      const u = state.tt.unallocated.find(x => x.id === item.dataset.un); if (!u) return;
      drag = { kind: 'tray', id: u.id, off: 0, a: { id: u.id, type: u.type, dur: u.dur, subjectId: u.subjectId, batchId: u.batchId, facultyId: u.facultyId, roomId: E.defaultRoom(u, state.data), day: 0, start: 0 } };
    }
    e.dataTransfer.effectAllowed = 'move'; e.dataTransfer.setData('text/plain', drag.id);
    setTimeout(() => {   // compute drop hints after the drag image is captured
      if (!drag) return;
      $$('#gridWrap td[data-d]').forEach(td => {
        const start = +td.dataset.p - drag.off;
        if (start < 0 || start + drag.a.dur > P) { td.classList.add('drop-bad'); return; }
        const base = drag.kind === 'alloc' ? state.tt.allocations : state.tt.allocations.concat([drag.a]);
        const sim = base.map(x => (x.id === drag.a.id ? Object.assign({}, x, { day: +td.dataset.d, start }) : x));
        const bad = E.audit(sim, [], state.data, { movedId: drag.a.id }).some(v => v.sev === 'error' && v.ids.includes(drag.a.id));
        td.classList.add(bad ? 'drop-bad' : 'drop-ok');
      });
    }, 0);
  }
  function onDrop(e) {
    const td = e.target.closest('#gridWrap td[data-d]'); if (!td || !drag) return;
    e.preventDefault();
    const day = +td.dataset.d, start = +td.dataset.p - drag.off, a0 = drag.a, kind = drag.kind, id = drag.id;
    drag = null; clearHints();
    if (start < 0 || start + a0.dur > P) { toast("That block doesn't fit in the day from this slot.", 'error'); return; }
    pushHistory();
    let a;
    if (kind === 'alloc') { a = state.tt.allocations.find(x => x.id === id); a.day = day; a.start = start; }
    else {
      a = Object.assign({}, a0, { day, start });
      state.tt.allocations.push(a); state.tt.unallocated = state.tt.unallocated.filter(u => u.id !== id);
    }
    state.movedId = a.id; state.flash = a.id;
    recompute(); save(); renderTimetable();
    const mine = state.audit.filter(v => v.sev === 'error' && v.ids.includes(a.id));
    if (mine.length) toast(mine[0].msg + (mine.length > 1 ? `  (+${mine.length - 1} more)` : ''), 'error');
    else toast('Moved. No conflicts.', 'ok');
  }
  function undo() {
    if (!state.history.length || !state.tt) return;
    state.tt = JSON.parse(state.history.pop()); state.movedId = null; state.flash = null;
    recompute(); save(); if (state.tab === 'timetable') renderTimetable();
    $('#undoBtn').disabled = !state.history.length; toast('Last move undone.');
  }

  /* ---------- card click: change room ---------- */
  function openCard(id) {
    const a = state.tt.allocations.find(x => x.id === id); if (!a) return;
    const d = state.data, S = byId(d.subjects), B = byId(d.batches), F = byId(d.faculty), m = $('#modal');
    m.innerHTML = `<form><div class="mh">${esc(S[a.subjectId].code)} · ${esc(S[a.subjectId].name)}</div><div class="mb">
      <div class="kv"><span>Batch</span><b>${esc(B[a.batchId].name)}</b></div>
      <div class="kv"><span>Faculty</span><b>${esc((F[a.facultyId] || {}).name)}</b></div>
      <div class="kv"><span>When</span><b>${DAYS[a.day]} P${a.start + 1}${a.dur > 1 ? '–P' + (a.start + a.dur) : ''} (${a.type})</b></div>
      <label class="f">Room<select name="room">${d.rooms.map(r => `<option value="${r.id}" ${r.id === a.roomId ? 'selected' : ''}>${esc(r.name)} · ${r.capacity} seats${r.type === 'lab' ? ' · lab' : ''}</option>`).join('')}</select></label>
      <span class="hint">Tip: drag cards to other slots to reschedule. Clashes appear in red immediately.</span></div>
      <div class="mf"><button type="button" class="btn" data-close>Close</button><button type="submit" class="btn primary">Change room</button></div></form>`;
    $('[data-close]', m).addEventListener('click', () => m.close());
    $('form', m).addEventListener('submit', ev => {
      ev.preventDefault(); const r = $('[name="room"]', m).value;
      if (r !== a.roomId) { pushHistory(); a.roomId = r; state.movedId = a.id; state.flash = a.id; recompute(); save(); renderTimetable(); const mine = state.audit.filter(v => v.sev === 'error' && v.ids.includes(a.id)); mine.length ? toast(mine[0].msg, 'error') : toast('Room changed. No conflicts.', 'ok'); }
      m.close();
    });
    m.showModal();
  }

  /* ================= exports ================= */
  function download(name, text, type) {
    const blob = new Blob([text], { type: type || 'text/plain' }), url = URL.createObjectURL(blob);
    const a = document.createElement('a'); a.href = url; a.download = name; document.body.appendChild(a); a.click();
    setTimeout(() => { URL.revokeObjectURL(url); a.remove(); }, 300);
  }
  const slug = s => String(s).toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');
  function exportIcs() {
    const d = state.data, v = state.view, ent = entityList().find(x => x.id === v.id); if (!ent) return;
    const allocs = state.tt.allocations.filter(a => (v.mode === 'batch' ? a.batchId : v.mode === 'faculty' ? a.facultyId : a.roomId) === v.id);
    const label = (a, x) => v.mode === 'batch' ? `${x.s.code} ${x.s.name}${a.type === 'lab' ? ' (Lab)' : ''} — ${x.f.name}` : `${x.s.code} ${x.s.name}${a.type === 'lab' ? ' (Lab)' : ''} — ${x.b.name}`;
    const ics = E.buildIcs(`${ent.name} timetable`, allocs, d, d.settings.semesterStart, d.settings.weeks, label);
    download(`timetable-${slug(ent.name)}.ics`, ics, 'text/calendar');
    toast(`Saved ${ent.name}.ics — import it into Google Calendar, Outlook or Apple Calendar.`, 'ok');
  }
  function exportPdf() {
    const d = state.data, v = state.view, scope = $('#scopeSel') ? $('#scopeSel').value : 'view';
    state.scope = scope;
    const jobs = scope === 'view' ? [[v.mode, v.id]] : (scope === 'batch' ? d.batches : scope === 'faculty' ? d.faculty : d.rooms).map(x => [scope, x.id]);
    const lists = { batch: d.batches, faculty: d.faculty, room: d.rooms }, kindName = { batch: 'Batch', faculty: 'Faculty', room: 'Room' };
    const date = new Date().toLocaleDateString();
    $('#printArea').innerHTML = jobs.map(([m, id]) => {
      const ent = lists[m].find(x => x.id === id); if (!ent) return '';
      return `<section class="sheet"><h2>${kindName[m]} timetable — ${esc(ent.name)}</h2><p class="meta">ClassClockwork · generated ${esc(date)}${m === 'batch' ? ' · ' + ent.size + ' students' : ''}</p>${gridHtml(m, id, false)}<div class="foot">Lunch break is common to all batches. Labs are continuous blocks.</div></section>`;
    }).join('');
    const clear = () => { $('#printArea').innerHTML = ''; window.removeEventListener('afterprint', clear); };
    window.addEventListener('afterprint', clear);
    setTimeout(() => window.print(), 60);
  }
  function exportJson() {
    download('classclockwork-data.json', JSON.stringify({ app: 'ClassClockwork', version: 1, data: state.data, timetable: state.tt }, null, 2), 'application/json');
  }
  function importJson(file) {
    const r = new FileReader();
    r.onload = () => {
      try {
        const j = JSON.parse(r.result), d = j.data || j;
        if (!(d.batches && d.subjects && d.faculty && d.rooms)) throw new Error('Missing batches, subjects, faculty or rooms.');
        d.settings = Object.assign({ lunchAfter: 3, maxPerDay: 5, maxConsecutive: 3, semesterStart: nextMonday(), weeks: 16 }, d.settings || {});
        const issues = window.CCValidation.validate(d); if (issues.length) throw new Error(issues.slice(0, 4).map(x => `${x.path}: ${x.message}`).join(' | '));
        state.data = d; state.tt = j.timetable && Array.isArray(j.timetable.allocations) ? j.timetable : null; state.history = []; state.stale = false;
        recompute(); save(); switchTab('resources'); toast('Imported ' + file.name, 'ok');
      } catch (err) { toast('Could not import: ' + err.message, 'error'); }
    };
    r.readAsText(file);
  }

  /* ================= events ================= */
  document.addEventListener('click', e => {
    const t = e.target.closest('[data-act],[data-tab],[data-view]');
    if (t) {
      if (t.dataset.tab) return switchTab(t.dataset.tab);
      if (t.dataset.view) { state.view.mode = t.dataset.view; state.view.id = null; renderTimetable(); return; }
      const act = t.dataset.act, kind = t.dataset.kind, id = t.dataset.id;
      if (act === 'add') return openForm(kind);
      if (act === 'edit') return openForm(kind, id);
      if (act === 'del') return deleteItem(kind, id);
      if (act === 'generate') return generate(false);
      if (act === 'regen') return generate(true);
      if (act === 'pdf') return exportPdf();
      if (act === 'ics') return exportIcs();
      if (act === 'export-json') return exportJson();
      if (act === 'import-json') return $('#importFile').click();
      if (act === 'reset') { if (confirm('Delete all resources and the timetable from this browser?')) { state.data = { settings: Object.assign({}, SAMPLES.cs.settings, { semesterStart: nextMonday() }), batches: [], subjects: [], faculty: [], rooms: [] }; state.tt = null; state.history = []; state.stale = false; recompute(); save(); renderResources(); } return; }
    }
    const li = e.target.closest('.viol li[data-ids]');
    if (li && li.dataset.ids) {
      const ids = li.dataset.ids.split(','), a = state.tt.allocations.find(x => x.id === ids[0]);
      if (a) { if (state.view.mode === 'batch') state.view.id = a.batchId; else if (state.view.mode === 'faculty') state.view.id = a.facultyId; else state.view.id = a.roomId; state.flash = a.id; renderTimetable(); }
      return;
    }
    const card = e.target.closest('#gridWrap .card[data-id]');
    if (card) openCard(card.dataset.id);
  });
  document.addEventListener('change', e => {
    if (e.target.id === 'entitySel') { state.view.id = e.target.value; renderTimetable(); }
    else if (e.target.id === 'scopeSel') state.scope = e.target.value;
    else if (e.target.dataset && e.target.dataset.set) {
      const k = e.target.dataset.set, previous = state.data.settings[k];
      state.data.settings[k] = e.target.type === 'number' || k === 'lunchAfter' ? Number(e.target.value) : e.target.value;
      const issues = window.CCValidation.validate(state.data);
      if (issues.length) { state.data.settings[k] = previous; toast(issues[0].message, 'error'); renderResources(); return; }
      if (state.tt) state.stale = true; recompute(); save(); renderResources();
    } else if (e.target.id === 'importFile' && e.target.files[0]) { importJson(e.target.files[0]); e.target.value = ''; }
    else if (e.target.id === 'sampleSelect') {
      const k = e.target.value; e.target.value = ''; if (!k) return;
      if (confirm('Replace current data with this sample?')) { loadSample(k); recompute(); save(); switchTab('resources'); toast('Sample loaded. Press “Generate timetable”.', 'ok'); }
    }
  });
  document.addEventListener('dragstart', onDragStart);
  document.addEventListener('dragend', () => { drag = null; clearHints(); });
  document.addEventListener('dragover', e => { const td = e.target.closest('#gridWrap td[data-d]'); if (td && drag) { e.preventDefault(); $$('#gridWrap td.drop-over').forEach(x => x.classList.remove('drop-over')); td.classList.add('drop-over'); } });
  document.addEventListener('drop', onDrop);
  document.addEventListener('keydown', e => { if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'z' && state.tab === 'timetable' && !e.target.closest('input,select,textarea')) { e.preventDefault(); undo(); } });
  $('#generateBtn').addEventListener('click', () => generate(false));
  $('#undoBtn').addEventListener('click', undo);
  $('#modal').addEventListener('click', e => { if (e.target.id === 'modal') e.target.close(); });

  /* ================= boot ================= */
  if (!restore()) loadSample('cs');
  if (!state.data.settings.semesterStart) state.data.settings.semesterStart = nextMonday();
  recompute(); ensureView();
  switchTab(state.tt ? 'timetable' : 'resources');
  window.__cc = { state, E };   // handy for debugging in the browser console
})();
