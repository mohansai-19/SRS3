/* Sample datasets for ClassClockwork.
 * Day index: 0=Mon … 4=Fri. Period index: 0..5 (P1..P6).
 * faculty.unavailable is a list of "day-period" strings, e.g. "4-3" = Friday P4.
 */
(function (global) {
  'use strict';
  const blk = (day, periods) => periods.map(p => `${day}-${p}`);
  const allDay = d => blk(d, [0, 1, 2, 3, 4, 5]);
  const morning = d => blk(d, [0, 1, 2]);
  const afternoon = d => blk(d, [3, 4, 5]);

  const settings = () => ({ lunchAfter: 3, maxPerDay: 5, maxConsecutive: 3, semesterStart: '', weeks: 16 });

  // ---------- Sample 1: CS semester – 3 batches, 8 subjects, 10 faculty, 6 rooms ----------
  const cs = {
    settings: settings(),
    batches: [
      { id: 'b1', name: 'CS-A', size: 60 },
      { id: 'b2', name: 'CS-B', size: 55 },
      { id: 'b3', name: 'CS-C', size: 50 }
    ],
    faculty: [
      { id: 'f1', name: 'Dr. Sharma',    maxLoad: 12, preference: 'morning',   unavailable: afternoon(4) },
      { id: 'f2', name: 'Dr. Rao',       maxLoad: 10, preference: 'none',      unavailable: morning(2) },
      { id: 'f3', name: 'Mr. Khan',      maxLoad: 12, preference: 'afternoon', unavailable: morning(0) },
      { id: 'f4', name: 'Prof. Iyer',    maxLoad: 10, preference: 'morning',   unavailable: blk(1, [0, 1]) },
      { id: 'f5', name: 'Ms. Nair',      maxLoad: 10, preference: 'none',      unavailable: allDay(4) },
      { id: 'f6', name: 'Dr. Mehta',     maxLoad: 8,  preference: 'none',      unavailable: allDay(3) },
      { id: 'f7', name: 'Dr. Banerjee',  maxLoad: 12, preference: 'morning',   unavailable: [].concat(blk(0, [5]), blk(1, [5]), blk(2, [5])) },
      { id: 'f8', name: 'Prof. Gupta',   maxLoad: 8,  preference: 'none',      unavailable: afternoon(2) },
      { id: 'f9', name: 'Ms. Das',       maxLoad: 8,  preference: 'none',      unavailable: blk(4, [0, 1]) },
      { id: 'f10', name: 'Mr. Thomas',   maxLoad: 6,  preference: 'afternoon', unavailable: [].concat(allDay(0), allDay(1)) }
    ],
    rooms: [
      { id: 'r1', name: 'Room 101', capacity: 70, type: 'classroom', equipment: ['Projector'] },
      { id: 'r2', name: 'Room 102', capacity: 65, type: 'classroom', equipment: ['Projector'] },
      { id: 'r3', name: 'Room 103', capacity: 60, type: 'classroom', equipment: [] },
      { id: 'r4', name: 'Lab 1 (DB Lab)', capacity: 60, type: 'lab', equipment: ['Computers', 'Database'] },
      { id: 'r5', name: 'Lab 2 (OS Lab)', capacity: 60, type: 'lab', equipment: ['Computers', 'Linux'] },
      { id: 'r6', name: 'Lab 3 (Network Lab)', capacity: 60, type: 'lab', equipment: ['Computers', 'Networking'] }
    ],
    subjects: [
      { id: 's1', code: 'CS201', name: 'Data Structures',          credits: 3, lectureHours: 3, labHours: 0, facultyId: 'f1', labFacultyId: '',   labEquipment: '',         batchIds: ['b1', 'b2', 'b3'] },
      { id: 's2', code: 'CS202', name: 'Operating Systems',        credits: 4, lectureHours: 2, labHours: 3, facultyId: 'f2', labFacultyId: 'f3', labEquipment: 'Linux',    batchIds: ['b1', 'b2', 'b3'] },
      { id: 's3', code: 'CS203', name: 'Database Systems',         credits: 4, lectureHours: 2, labHours: 2, facultyId: 'f4', labFacultyId: 'f5', labEquipment: 'Database', batchIds: ['b1', 'b2', 'b3'] },
      { id: 's4', code: 'CS204', name: 'Computer Networks',        credits: 3, lectureHours: 2, labHours: 0, facultyId: 'f6', labFacultyId: '',   labEquipment: '',         batchIds: ['b1', 'b2', 'b3'] },
      { id: 's5', code: 'MA201', name: 'Discrete Mathematics',     credits: 4, lectureHours: 3, labHours: 0, facultyId: 'f7', labFacultyId: '',   labEquipment: '',         batchIds: ['b1', 'b2', 'b3'] },
      { id: 's6', code: 'CS205', name: 'Theory of Computation',    credits: 3, lectureHours: 2, labHours: 0, facultyId: 'f8', labFacultyId: '',   labEquipment: '',         batchIds: ['b1', 'b2', 'b3'] },
      { id: 's7', code: 'CS206', name: 'Software Engineering',     credits: 3, lectureHours: 2, labHours: 0, facultyId: 'f9', labFacultyId: '',   labEquipment: '',         batchIds: ['b1', 'b2', 'b3'] },
      { id: 's8', code: 'HS201', name: 'Professional Communication', credits: 2, lectureHours: 1, labHours: 0, facultyId: 'f10', labFacultyId: '', labEquipment: '',         batchIds: ['b1', 'b2', 'b3'] }
    ]
  };

  // ---------- Sample 2: hackathon demo – 6 subjects, 5 faculty, 4 rooms (incl. 3-hour OS lab) ----------
  const demo = {
    settings: settings(),
    batches: [
      { id: 'b1', name: 'CS-A', size: 60 },
      { id: 'b2', name: 'CS-B', size: 55 }
    ],
    faculty: [
      { id: 'f1', name: 'Dr. Sharma',   maxLoad: 12, preference: 'morning', unavailable: afternoon(4) },
      { id: 'f2', name: 'Dr. Rao',      maxLoad: 12, preference: 'none',    unavailable: morning(2) },
      { id: 'f3', name: 'Prof. Iyer',   maxLoad: 10, preference: 'none',    unavailable: [] },
      { id: 'f4', name: 'Dr. Mehta',    maxLoad: 8,  preference: 'none',    unavailable: allDay(3) },
      { id: 'f5', name: 'Dr. Banerjee', maxLoad: 10, preference: 'morning', unavailable: blk(0, [5]) }
    ],
    rooms: [
      { id: 'r1', name: 'Room 101', capacity: 70, type: 'classroom', equipment: [] },
      { id: 'r2', name: 'Room 102', capacity: 65, type: 'classroom', equipment: [] },
      { id: 'r3', name: 'Room 103', capacity: 60, type: 'classroom', equipment: [] },
      { id: 'r4', name: 'OS Lab', capacity: 60, type: 'lab', equipment: ['Computers', 'Linux'] }
    ],
    subjects: [
      { id: 's1', code: 'CS201', name: 'Data Structures',      credits: 3, lectureHours: 3, labHours: 0, facultyId: 'f1', labFacultyId: '', labEquipment: '',      batchIds: ['b1', 'b2'] },
      { id: 's2', code: 'CS202', name: 'Operating Systems',    credits: 4, lectureHours: 2, labHours: 3, facultyId: 'f2', labFacultyId: '', labEquipment: 'Linux', batchIds: ['b1', 'b2'] },
      { id: 's3', code: 'CS203', name: 'Database Systems',     credits: 3, lectureHours: 3, labHours: 0, facultyId: 'f3', labFacultyId: '', labEquipment: '',      batchIds: ['b1', 'b2'] },
      { id: 's4', code: 'CS204', name: 'Computer Networks',    credits: 3, lectureHours: 2, labHours: 0, facultyId: 'f4', labFacultyId: '', labEquipment: '',      batchIds: ['b1', 'b2'] },
      { id: 's5', code: 'MA201', name: 'Discrete Mathematics', credits: 4, lectureHours: 3, labHours: 0, facultyId: 'f5', labFacultyId: '', labEquipment: '',      batchIds: ['b1', 'b2'] },
      { id: 's6', code: 'CS206', name: 'Software Engineering', credits: 3, lectureHours: 2, labHours: 0, facultyId: 'f1', labFacultyId: '', labEquipment: '',      batchIds: ['b1', 'b2'] }
    ]
  };

  global.CC_SAMPLES = { cs, demo };
})(window);
