/* ClassClockwork engine: CSP solver (backtracking + MRV + forward checking),
 * clash auditor, workload metrics (Gini), pre-flight diagnostics and .ics export.
 * No DOM access in here, so it can be ported to Node/TypeScript unchanged.
 */
(function (global) {
  'use strict';

  const D = 5, P = 6;
  const DAYS = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri'];
  const now = () => (typeof performance !== 'undefined' ? performance.now() : Date.now());
  const byId = arr => Object.fromEntries((arr || []).map(x => [x.id, x]));
  const num = (v, d) => (Number.isFinite(+v) && v !== '' && v !== null ? +v : d);

  function mulberry32(a) {
    return function () {
      a |= 0; a = (a + 0x6D2B79F5) | 0;
      let t = Math.imul(a ^ (a >>> 15), 1 | a);
      t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  }

  /* ---------- time helpers ---------- */
  const fmt = m => String(Math.floor(m / 60)).padStart(2, '0') + ':' + String(m % 60).padStart(2, '0');
  function periodTimes(L) {
    let t = 9 * 60; const slots = []; let lunch = null;
    for (let p = 0; p < P; p++) {
      if (p === L) { lunch = { s: fmt(t), e: fmt(t + 60) }; t += 60; }
      slots.push({ s: fmt(t), e: fmt(t + 60) }); t += 60;
    }
    return { slots, lunch };
  }
  function validStarts(dur, L) {
    const out = [];
    for (const [a, b] of [[0, L], [L, P]]) for (let s = a; s + dur <= b; s++) out.push(s);
    return out;
  }

  /* ---------- context & sessions ---------- */
  function makeCtx(data) {
    const st = data.settings || {};
    return {
      data, P, D,
      L: num(st.lunchAfter, 3),
      maxPerDay: num(st.maxPerDay, 5),
      maxConsec: num(st.maxConsecutive, 3),
      fac: byId(data.faculty), batch: byId(data.batches), subj: byId(data.subjects), room: byId(data.rooms)
    };
  }

  function buildSessions(data) {
    const out = [];
    for (const b of data.batches) for (const s of data.subjects) {
      if (!(s.batchIds || []).includes(b.id)) continue;
      const lec = num(s.lectureHours, 0), lab = num(s.labHours, 0);
      for (let k = 0; k < lec; k++) out.push({ id: `${b.id}|${s.id}|L${k}`, type: 'lecture', dur: 1, subjectId: s.id, batchId: b.id, facultyId: s.facultyId, k, group: `${b.id}|${s.id}|L` });
      if (lab > 0) out.push({ id: `${b.id}|${s.id}|LAB`, type: 'lab', dur: lab, subjectId: s.id, batchId: b.id, facultyId: s.labFacultyId || s.facultyId, k: 0, group: `${b.id}|${s.id}|LAB` });
    }
    return out;
  }

  /* Static analysis: all (day, start, room) candidates that satisfy constraints
   * which do not depend on other sessions. Returns a human reason if none exist. */
  function analyse(sess, ctx) {
    const f = ctx.fac[sess.facultyId], b = ctx.batch[sess.batchId], s = ctx.subj[sess.subjectId];
    if (!f) return { cands: [], reason: 'No faculty assigned' };
    const type = sess.type === 'lab' ? 'lab' : 'classroom';
    let rooms = ctx.data.rooms.filter(r => r.type === type);
    if (!rooms.length) return { cands: [], reason: `No ${type === 'lab' ? 'laboratory' : 'classroom'} rooms defined` };
    rooms = rooms.filter(r => num(r.capacity, 0) >= num(b.size, 0));
    if (!rooms.length) return { cands: [], reason: `No ${type === 'lab' ? 'lab' : 'classroom'} seats ${b.size} students (${b.name})` };
    if (sess.type === 'lab' && s.labEquipment) {
      const need = s.labEquipment.trim().toLowerCase();
      rooms = rooms.filter(r => (r.equipment || []).some(e => e.trim().toLowerCase() === need));
      if (!rooms.length) return { cands: [], reason: `No lab has the required equipment “${s.labEquipment}”` };
    }
    const starts = validStarts(sess.dur, ctx.L);
    if (!starts.length) return { cands: [], reason: `A ${sess.dur}-hour block cannot fit between the lunch break and the day's edges` };
    const unav = new Set(f.unavailable || []);
    const cands = [];
    for (let d = 0; d < D; d++) for (const st of starts) {
      let ok = true;
      for (let i = 0; i < sess.dur; i++) if (unav.has(`${d}-${st + i}`)) { ok = false; break; }
      if (!ok) continue;
      for (const r of rooms) cands.push({ d, st, room: r.id, cap: num(r.capacity, 0) });
    }
    if (!cands.length) return { cands: [], reason: `${f.name} has no free ${sess.dur}-period window in their availability` };
    return { cands, reason: null };
  }

  /* ---------- one solver attempt ---------- */
  function runAttempt(sessions, ctx, mode, seed, budgetMs) {
    const { data, L } = ctx, SL = D * P;
    const rng = mulberry32(seed * 9301 + mode.id * 49297);
    const facBusy = {}, roomBusy = {}, batchBusy = {}, facLoad = {}, facDay = {}, batchDay = {};
    data.faculty.forEach(f => { facBusy[f.id] = new Uint8Array(SL); facLoad[f.id] = 0; facDay[f.id] = new Array(D).fill(0); });
    data.rooms.forEach(r => { roomBusy[r.id] = new Uint8Array(SL); });
    data.batches.forEach(b => { batchBusy[b.id] = new Uint8Array(SL); batchDay[b.id] = new Array(D).fill(0); });

    const statics = new Map();
    sessions.forEach(s => statics.set(s.id, analyse(s, ctx)));
    const pending = new Set(sessions);
    const skipped = new Set();
    const assigned = new Map();           // session id -> candidate
    const groupAssigned = {};             // group -> [{k,d,st}] (LIFO)
    const deadline = now() + budgetMs, maxNodes = 400000;
    let nodes = 0, aborted = false, snap = null;
    const t0 = now();

    function batchLimitsOk(b, d, st, sess) {
      const bb = batchBusy[b], base = d * P, code = sess.type === 'lab' ? 2 : 1;
      if (batchDay[b][d] + sess.dur > ctx.maxPerDay) return false;
      let run = 0, lab = false;
      for (let p = 0; p <= P; p++) {
        if (p === P || p === L) { if (run > ctx.maxConsec && !lab) return false; run = 0; lab = false; }
        if (p === P) break;
        let v = bb[base + p]; if (p >= st && p < st + sess.dur) v = code;
        if (v) { run++; if (v === 2) lab = true; }
        else { if (run > ctx.maxConsec && !lab) return false; run = 0; lab = false; }
      }
      return true;
    }

    function feasible(sess, c) {
      const f = sess.facultyId, b = sess.batchId, base = c.d * P + c.st;
      const fb = facBusy[f], rb = roomBusy[c.room], bb = batchBusy[b];
      for (let i = 0; i < sess.dur; i++) { const sl = base + i; if (fb[sl] || rb[sl] || bb[sl]) return false; }
      if (facLoad[f] + sess.dur > num(ctx.fac[f].maxLoad, 99)) return false;
      const sib = groupAssigned[sess.group];
      if (sib) for (const o of sib) {
        if (mode.strict) { if (o.k < sess.k ? o.d >= c.d : o.d <= c.d) return false; }
        else { const oo = o.d * P + o.st; if (o.k < sess.k ? oo >= base : oo <= base) return false; }
      }
      if (mode.strict && !batchLimitsOk(b, c.d, c.st, sess)) return false;
      return true;
    }

    function assign(sess, c) {
      const base = c.d * P + c.st, code = sess.type === 'lab' ? 2 : 1;
      for (let i = 0; i < sess.dur; i++) { facBusy[sess.facultyId][base + i] = 1; roomBusy[c.room][base + i] = 1; batchBusy[sess.batchId][base + i] = code; }
      facLoad[sess.facultyId] += sess.dur; facDay[sess.facultyId][c.d] += sess.dur; batchDay[sess.batchId][c.d] += sess.dur;
      (groupAssigned[sess.group] || (groupAssigned[sess.group] = [])).push({ k: sess.k, d: c.d, st: c.st });
      assigned.set(sess.id, c); pending.delete(sess);
    }
    function unassign(sess, c) {
      const base = c.d * P + c.st;
      for (let i = 0; i < sess.dur; i++) { facBusy[sess.facultyId][base + i] = 0; roomBusy[c.room][base + i] = 0; batchBusy[sess.batchId][base + i] = 0; }
      facLoad[sess.facultyId] -= sess.dur; facDay[sess.facultyId][c.d] -= sess.dur; batchDay[sess.batchId][c.d] -= sess.dur;
      groupAssigned[sess.group].pop();
      assigned.delete(sess.id); pending.add(sess);
    }

    function cost(s, c) {
      const f = ctx.fac[s.facultyId], b = s.batchId, aft = c.st >= L;
      let k = rng() * 0.4;
      if (f.preference === 'morning' && aft) k += 4;
      if (f.preference === 'afternoon' && !aft) k += 4;
      k += batchDay[b][c.d] * 1.5 + facDay[s.facultyId][c.d] * 0.6;
      if (s.type === 'lab') { if (!aft) k += 3; } else if (aft) k += 0.6;
      k += (c.cap - num(ctx.batch[b].size, 0)) / 60;
      const bb = batchBusy[b], base = c.d * P + c.st;
      if ((c.st > 0 && c.st !== L && bb[base - 1]) || (c.st + s.dur < P && c.st + s.dur !== L && bb[base + s.dur])) k -= 0.8; // compact day, fewer gaps
      if (!mode.strict) { const sib = groupAssigned[s.group]; if (sib && sib.some(o => o.d === c.d)) k += 10; }
      return k;
    }

    function snapshot() { snap = [...assigned.entries()]; }

    function search() {
      if (++nodes > maxNodes || ((nodes & 31) === 0 && now() > deadline)) { aborted = true; snapshot(); return false; }
      let best = null, bestC = null, bestN = 1e9;
      const drop = [];
      for (const s of pending) {
        const st = statics.get(s.id);
        if (st.reason) { if (mode.skip) { drop.push(s); continue; } return false; }
        const cs = [];
        for (const c of st.cands) if (feasible(s, c)) cs.push(c);
        if (!cs.length) { if (mode.skip) { drop.push(s); continue; } return false; }   // forward-check dead end
        if (cs.length < bestN || (cs.length === bestN && s.dur > best.dur)) { best = s; bestC = cs; bestN = cs.length; }  // MRV
      }
      drop.forEach(s => { pending.delete(s); skipped.add(s); });
      if (!best) return true;
      const ordered = bestC.map(c => ({ c, k: cost(best, c) })).sort((a, b) => a.k - b.k);
      for (const { c } of ordered) {
        assign(best, c);
        if (search()) return true;
        unassign(best, c);
        if (aborted) break;
      }
      drop.forEach(s => { skipped.delete(s); pending.add(s); });
      return false;
    }

    const complete = search();
    const ms = now() - t0;
    const allocations = [], unallocated = [];
    const entries = complete ? [...assigned.entries()] : (snap || []);
    const placed = new Set(entries.map(e => e[0]));
    const sessById = new Map(sessions.map(s => [s.id, s]));
    for (const [id, c] of entries) {
      const s = sessById.get(id);
      allocations.push({ id, subjectId: s.subjectId, batchId: s.batchId, facultyId: s.facultyId, roomId: c.room, day: c.d, start: c.st, dur: s.dur, type: s.type });
    }
    for (const s of sessions) if (!placed.has(s.id)) {
      const st = statics.get(s.id); let reason = st.reason;
      if (!reason) {
        const f = ctx.fac[s.facultyId];
        if (complete && facLoad[s.facultyId] + s.dur > num(f.maxLoad, 99)) reason = `${f.name} would exceed the workload limit (${f.maxLoad} h/week)`;
        else reason = aborted ? 'Solver time limit reached before a slot was found' : 'No conflict-free slot left (faculty, room or batch already busy)';
      }
      unallocated.push({ id: s.id, subjectId: s.subjectId, batchId: s.batchId, facultyId: s.facultyId, type: s.type, dur: s.dur, reason });
    }
    return { complete, allocations, unallocated, nodes, ms, aborted };
  }

  function solve(data, opts) {
    opts = opts || {};
    const t0 = now(), ctx = makeCtx(data), sessions = buildSessions(data), seed = opts.seed || 1;
    const strictPossible = sessions.every(s => s.type !== 'lecture' || num(ctx.subj[s.subjectId].lectureHours, 0) <= D);
    const modes = [
      { id: 1, name: 'Strict', note: 'all hard rules + balanced days', strict: true, skip: false, ms: 800 },
      { id: 2, name: 'Relaxed', note: 'soft rules dropped', strict: false, skip: false, ms: 600 },
      { id: 3, name: 'Best-effort', note: 'unplaceable classes left unallocated', strict: false, skip: true, ms: 500 }
    ];
    const attempts = []; let res = null, nodes = 0;
    for (const m of modes) {
      if (m.id === 1 && !strictPossible) { attempts.push({ name: m.name, note: 'skipped: a subject has more lectures than days', nodes: 0, ms: 0, ok: false }); continue; }
      const r = runAttempt(sessions, ctx, m, seed, m.ms);
      nodes += r.nodes;
      const ok = r.complete && r.unallocated.length === 0;
      attempts.push({ name: m.name, note: m.note, nodes: r.nodes, ms: Math.round(r.ms), ok });
      res = r; res.mode = m.name;
      if (ok) break;
    }
    return {
      allocations: res.allocations, unallocated: res.unallocated,
      stats: { total: sessions.length, placed: res.allocations.length, ms: Math.round(now() - t0), nodes, attempts, seed, mode: res.mode }
    };
  }

  /* ---------- clash auditor ---------- */
  function audit(allocs, unalloc, data, opts) {
    opts = opts || {};
    const L = num((data.settings || {}).lunchAfter, 3), maxPerDay = num((data.settings || {}).maxPerDay, 5);
    const Fm = byId(data.faculty), Bm = byId(data.batches), Sm = byId(data.subjects), Rm = byId(data.rooms);
    const unk = { name: '(deleted)', code: '?', size: 0, capacity: 0, unavailable: [], maxLoad: 99, type: 'classroom', equipment: [], preference: 'none' };
    const F = id => Fm[id] || unk, B = id => Bm[id] || unk, S = id => Sm[id] || unk, R = id => Rm[id] || unk;
    const lab = a => `${B(a.batchId).name} ${S(a.subjectId).code}`;
    const when = a => `${DAYS[a.day]} P${a.start + 1}${a.dur > 1 ? '–P' + (a.start + a.dur) : ''}`;
    const v = [];
    const add = (sev, type, msg, ids) => v.push({ sev, type, msg, ids: ids || [] });

    for (let i = 0; i < allocs.length; i++) for (let j = i + 1; j < allocs.length; j++) {
      const a = allocs[i], b = allocs[j];
      if (a.day !== b.day || !(a.start < b.start + b.dur && b.start < a.start + a.dur)) continue;
      let x = a; if (opts.movedId && a.id === opts.movedId) x = b;   // x = the class that was "already there"
      if (a.facultyId === b.facultyId) add('error', 'faculty', `Clash: ${F(a.facultyId).name} already booked in ${R(x.roomId).name} (${lab(x)}, ${when(x)})`, [a.id, b.id]);
      if (a.roomId === b.roomId) add('error', 'room', `Clash: ${R(a.roomId).name} already used by ${F(x.facultyId).name} for ${lab(x)} (${when(x)})`, [a.id, b.id]);
      if (a.batchId === b.batchId) add('error', 'batch', `Clash: ${B(a.batchId).name} already has ${S(x.subjectId).code} (${when(x)})`, [a.id, b.id]);
    }

    const load = {}, prefMiss = {}, prefTot = {}, dayLect = {}, batchDay = {};
    for (const a of allocs) {
      const f = F(a.facultyId), r = R(a.roomId), b = B(a.batchId), s = S(a.subjectId);
      load[a.facultyId] = (load[a.facultyId] || 0) + a.dur;
      if (num(r.capacity, 0) < num(b.size, 0)) add('error', 'capacity', `Capacity exceeded: ${r.name} seats ${r.capacity} but ${b.name} has ${b.size} students (${s.code}, ${when(a)})`, [a.id]);
      if (a.type === 'lab' && r.type !== 'lab') add('error', 'roomtype', `${s.code} lab needs a laboratory — ${r.name} is a classroom (${b.name}, ${when(a)})`, [a.id]);
      if (a.type === 'lecture' && r.type === 'lab') add('warn', 'roomtype', `${s.code} lecture is using lab room ${r.name} (${b.name}, ${when(a)})`, [a.id]);
      if (a.type === 'lab' && s.labEquipment && !(r.equipment || []).some(e => e.trim().toLowerCase() === s.labEquipment.trim().toLowerCase()))
        add('error', 'equipment', `${r.name} lacks required equipment “${s.labEquipment}” for ${s.code} lab (${b.name}, ${when(a)})`, [a.id]);
      if (a.start + a.dur > P) add('error', 'bounds', `${lab(a)} runs past the last period (${when(a)})`, [a.id]);
      if (a.start < L && a.start + a.dur > L) add('error', 'lunch', `${lab(a)} overlaps the lunch break (${when(a)})`, [a.id]);
      const un = new Set(f.unavailable || []);
      for (let k = 0; k < a.dur; k++) if (un.has(`${a.day}-${a.start + k}`)) { add('error', 'availability', `${f.name} is unavailable on ${DAYS[a.day]} P${a.start + k + 1} (${lab(a)})`, [a.id]); break; }
      if (a.type === 'lecture') { const key = `${a.batchId}|${a.subjectId}|${a.day}`; (dayLect[key] = dayLect[key] || []).push(a.id); }
      const bk = `${a.batchId}|${a.day}`; batchDay[bk] = (batchDay[bk] || 0) + a.dur;
      if (f.preference === 'morning' || f.preference === 'afternoon') {
        prefTot[a.facultyId] = (prefTot[a.facultyId] || 0) + 1;
        if ((f.preference === 'morning') !== (a.start < L)) prefMiss[a.facultyId] = (prefMiss[a.facultyId] || 0) + 1;
      }
    }
    for (const id in load) { const f = F(id); if (load[id] > num(f.maxLoad, 99)) add('error', 'load', `${f.name} is overloaded: ${load[id]} h scheduled, limit is ${f.maxLoad} h`, []); }
    for (const k in dayLect) if (dayLect[k].length > 1) { const [b, s, d] = k.split('|'); add('warn', 'repeat', `${B(b).name} has ${S(s).code} ${dayLect[k].length}× on ${DAYS[+d]} — consider spreading it out`, dayLect[k]); }
    for (const k in batchDay) if (batchDay[k] > maxPerDay) { const [b, d] = k.split('|'); add('warn', 'heavyday', `${B(b).name} has ${batchDay[k]} periods on ${DAYS[+d]} (limit ${maxPerDay})`, []); }
    for (const id in prefMiss) add('info', 'pref', `${F(id).name}: ${prefMiss[id]} of ${prefTot[id]} classes fall outside their preferred ${F(id).preference} slots`, []);
    for (const u of unalloc || []) add('warn', 'unallocated', `Unallocated: ${B(u.batchId).name} ${S(u.subjectId).code} ${u.type === 'lab' ? u.dur + 'h lab' : 'lecture'} — ${u.reason}`, []);
    const rank = { error: 0, warn: 1, info: 2 };
    v.sort((a, b) => rank[a.sev] - rank[b.sev]);
    return v;
  }

  /* ---------- workload metrics ---------- */
  function facultyLoads(allocs, data) {
    const out = {}; data.faculty.forEach(f => out[f.id] = 0);
    allocs.forEach(a => { if (a.facultyId in out) out[a.facultyId] += a.dur; });
    return out;
  }
  function gini(values) {
    const x = values.slice().sort((a, b) => a - b), n = x.length, sum = x.reduce((a, b) => a + b, 0);
    if (!n || sum === 0) return 0;
    let w = 0; x.forEach((v, i) => { w += (i + 1) * v; });
    return Math.max(0, (2 * w) / (n * sum) - (n + 1) / n);
  }

  /* ---------- pre-flight diagnostics ---------- */
  function diagnose(data) {
    const out = [], ctx = makeCtx(data), sessions = buildSessions(data), seen = {};
    for (const s of sessions) {
      const a = analyse(s, ctx);
      if (a.reason) {
        const sub = ctx.subj[s.subjectId], key = s.subjectId + s.type + a.reason;
        if (!seen[key]) { seen[key] = 1; out.push({ sev: 'error', msg: `${sub.code} ${s.type === 'lab' ? 'lab' : 'lectures'}: ${a.reason}` }); }
      }
    }
    const need = {};
    sessions.forEach(s => { need[s.facultyId] = (need[s.facultyId] || 0) + s.dur; });
    data.faculty.forEach(f => {
      const n = need[f.id] || 0; if (!n) return;
      if (n > num(f.maxLoad, 99)) out.push({ sev: 'error', msg: `${f.name} is assigned ${n} h/week but the limit is ${f.maxLoad} h` });
      const free = D * P - (f.unavailable || []).length;
      if (n > free) out.push({ sev: 'error', msg: `${f.name} needs ${n} periods but only ${free} are marked available` });
    });
    const perBatch = {};
    sessions.forEach(s => { perBatch[s.batchId] = (perBatch[s.batchId] || 0) + s.dur; });
    data.batches.forEach(b => {
      const n = perBatch[b.id] || 0, cap = D * ctx.maxPerDay;
      if (n > cap) out.push({ sev: 'error', msg: `${b.name} needs ${n} periods/week but the cap is ${cap} (${ctx.maxPerDay}/day)` });
      else if (n > cap * 0.9) out.push({ sev: 'warn', msg: `${b.name} uses ${n} of ${cap} allowed periods — very tight, expect relaxed rules` });
    });
    data.subjects.forEach(s => { if (num(s.lectureHours, 0) > D) out.push({ sev: 'warn', msg: `${s.code} has ${s.lectureHours} lectures/week; some days will repeat it (strict mode is skipped)` }); });
    const lecN = sessions.filter(s => s.type === 'lecture').length, labN = sessions.filter(s => s.type === 'lab').reduce((a, s) => a + s.dur, 0);
    const cr = data.rooms.filter(r => r.type === 'classroom').length, lr = data.rooms.filter(r => r.type === 'lab').length;
    if (lecN > cr * D * P) out.push({ sev: 'error', msg: `${lecN} lecture periods but classrooms only offer ${cr * D * P} slots/week` });
    if (labN > lr * D * P) out.push({ sev: 'error', msg: `${labN} lab periods but labs only offer ${lr * D * P} slots/week` });
    if (!out.length) out.push({ sev: 'ok', msg: `${sessions.length} classes to place — no obvious blockers found` });
    return out;
  }

  function defaultRoom(u, data) {
    const ctx = makeCtx(data), a = analyse(u, ctx);
    if (a.cands.length) return a.cands[0].room;
    const r = data.rooms.find(r => r.type === (u.type === 'lab' ? 'lab' : 'classroom')) || data.rooms[0];
    return r ? r.id : '';
  }

  /* ---------- iCalendar (.ics) export ---------- */
  function buildIcs(title, allocs, data, startStr, weeks, labelFn) {
    const times = periodTimes(num((data.settings || {}).lunchAfter, 3)).slots;
    const Fm = byId(data.faculty), Bm = byId(data.batches), Sm = byId(data.subjects), Rm = byId(data.rooms);
    let start = startStr ? new Date(startStr + 'T00:00:00') : new Date();
    if (isNaN(start)) start = new Date();
    start.setDate(start.getDate() - ((start.getDay() + 6) % 7));       // snap to Monday
    const pad = n => String(n).padStart(2, '0');
    const stamp = (d, hm) => `${d.getFullYear()}${pad(d.getMonth() + 1)}${pad(d.getDate())}T${hm.replace(':', '')}00`;
    const esc = s => String(s).replace(/\\/g, '\\\\').replace(/;/g, '\\;').replace(/,/g, '\\,').replace(/\n/g, '\\n');
    const fold = l => { const o = []; while (l.length > 74) { o.push(l.slice(0, 74)); l = ' ' + l.slice(74); } o.push(l); return o.join('\r\n'); };
    const lines = ['BEGIN:VCALENDAR', 'VERSION:2.0', 'PRODID:-//ClassClockwork//ZeroClash//EN', 'CALSCALE:GREGORIAN', 'X-WR-CALNAME:' + esc(title)];
    const nowStamp = new Date().toISOString().replace(/[-:]/g, '').replace(/\.\d+/, '');
    for (const a of allocs) {
      const d = new Date(start); d.setDate(d.getDate() + a.day);
      const s = Sm[a.subjectId] || {}, b = Bm[a.batchId] || {}, f = Fm[a.facultyId] || {}, r = Rm[a.roomId] || {};
      const summary = labelFn ? labelFn(a, { s, b, f, r }) : `${s.code} ${s.name}`;
      lines.push('BEGIN:VEVENT', `UID:${a.id.replace(/\|/g, '-')}@classclockwork`, `DTSTAMP:${nowStamp}`,
        `DTSTART:${stamp(d, times[a.start].s)}`, `DTEND:${stamp(d, times[a.start + a.dur - 1].e)}`,
        `RRULE:FREQ=WEEKLY;COUNT=${Math.max(1, num(weeks, 16))}`,
        'SUMMARY:' + esc(summary), 'LOCATION:' + esc(r.name || ''),
        'DESCRIPTION:' + esc(`${s.name} · ${b.name} · ${f.name}${a.type === 'lab' ? ' · Lab' : ''}`), 'END:VEVENT');
    }
    lines.push('END:VCALENDAR');
    return lines.map(fold).join('\r\n');
  }

  global.CCEngine = { D, P, DAYS, periodTimes, validStarts, buildSessions, solve, audit, facultyLoads, gini, diagnose, defaultRoom, buildIcs, makeCtx };
})(typeof window !== 'undefined' ? window : globalThis);
