# ClassClockwork – ZeroClash Timetable Generator

A browser-based timetable generator: add subjects, faculty and rooms, click **Generate timetable**, and a
backtracking constraint solver builds a conflict-free 5-day × 6-period grid. Drag classes around and the
auditor flags every clash in red as it happens.

## Run it in VS Code

1. Unzip the folder and open it in VS Code (`File → Open Folder…`).
2. Easiest: install the **Live Server** extension, right-click `index.html` → **Open with Live Server**.
3. No extension? Just double-click `index.html` – it works from `file://` too. There is no build step and no
   dependencies, and it runs fully offline.

## Quick demo (matches the hackathon brief)

1. Header dropdown → **Demo: 6 subjects · 5 faculty · 4 rooms** (includes a 3-hour OS lab).
2. Click **Generate timetable** – the grid appears in a few milliseconds.
3. Drag any class onto a slot where that professor (or room, or batch) is already busy.
   The card turns red and a toast reads, e.g. *"Clash: Dr. Sharma already booked in Room 102 (…)"*.
4. **Undo** (or Ctrl+Z) reverts the move.

The second sample (**CS semester**) has 3 batches, 8 subjects, 10 faculty with time restrictions and 6 rooms/labs.

## Features

| Brief item | Where |
|---|---|
| Academic Resource Manager | **Resources** tab – batches, subjects (lecture/lab hours, credits), faculty (availability grid, workload limit), rooms (capacity, type, equipment) |
| CSP engine (backtracking + MRV) | `js/engine.js` → `runAttempt()` / `solve()` |
| Interactive weekly grid, colour-coded, drag & drop | **Timetable** tab (labs move as one block) |
| Real-time clash auditor | right-hand panel; click an entry to jump to the class |
| Batch / Faculty view toggle | toolbar (plus a Room view) |
| PDF + printable export | **Export PDF / print** → choose *Save as PDF* in the print dialog. Scope: current view, all batches, all faculty, or all rooms (one page each) |
| Lunch optimizer | one uniform lunch break for all batches (Resources → *Lunch break after period*); no class can span it |
| Faculty workload balance | Gini coefficient + per-faculty load bars |
| iCal export | **Export .ics** for the selected batch/faculty/room (weekly recurring events from the semester start date) |
| Soft preferences | faculty *morning/afternoon* preference steers slot choice and is reported in the auditor |
| Persistence | auto-saved in `localStorage`; **Export/Import .json** acts as the JSON store |

## How the solver works

* Each class (one lecture period, or one lab block of N periods) is a variable; its domain is every
  (day, start period, room) that satisfies the static rules: room type, seats ≥ batch size, required equipment,
  faculty availability, and "block must not cross lunch".
* **MRV**: at every step the class with the fewest remaining feasible options is placed next, so labs and
  heavily restricted faculty go first. Forward checking abandons a branch the moment any class has zero options.
* Hard rules: no faculty / room / batch overlap, workload limit. Strict pass also enforces one lecture of a
  subject per day, max periods per day and max back-to-back lectures.
* Interchangeable lectures of one subject are ordered to remove symmetric search branches.
* Values are tried cheapest-first (preferences, spread across days, labs in the afternoon, compact days,
  smallest suitable room). **Another variant** changes the random tie-break seed.
* **Impossible inputs**: strict → relaxed → best-effort passes, each with a time budget. Anything that cannot be
  placed appears in the red *Unallocated* tray with a reason, and you can drag it onto the grid by hand.

## Files

```
index.html        page shell
css/style.css     styles + print stylesheet
js/data.js        sample datasets
js/engine.js      solver, auditor, Gini, diagnostics, .ics (no DOM – portable to Node/TypeScript)
js/app.js         UI: forms, grid, drag & drop, exports
```

## Notes

* The brief suggests React/TypeScript/Node/SQLite. This version is plain HTML/CSS/JS so it runs by opening one file;
  the solver in `engine.js` has no browser dependencies if you want to move it behind an Express API later.
* Grid is fixed at 5 days × 6 periods (1 hour each, starting 09:00).


## Quality, validation and automated tests (v1.1)

- `js/validation.js` validates required fields, numeric ranges, unique IDs, faculty/batch references, availability slots, and timetable settings.
- The same validation runs before saving resource forms, importing JSON, restoring saved data, and changing schedule settings.
- Invalid imported data is rejected with a readable error instead of being loaded into the application.
- Automated regression tests cover both sample datasets, duplicate IDs, broken references, solver conflict-freedom, contiguous 3-hour labs, and workload fairness.

### Run automated tests

Install Node.js 18 or newer, open this project folder in a terminal, then run:

```bash
npm test
```

The application itself still runs in the browser with Live Server and has no runtime dependencies.

### Security note

This is a local-first student project. It validates data at the application boundary and safely escapes user-entered text in the UI. It does not implement user accounts, server-side authorization, or multi-user access control; those would be required before deploying it as a production college system.
