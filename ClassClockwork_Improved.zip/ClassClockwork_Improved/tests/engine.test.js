const test = require('node:test');
const assert = require('node:assert/strict');
global.window = global;
require('../js/validation.js');
require('../js/data.js');
require('../js/engine.js');

test('provided demo and semester datasets pass validation', () => {
  assert.deepEqual(CCValidation.validate(CC_SAMPLES.demo), []);
  assert.deepEqual(CCValidation.validate(CC_SAMPLES.cs), []);
});

test('validation rejects duplicate IDs and broken references', () => {
  const d = structuredClone(CC_SAMPLES.demo);
  d.batches.push({ ...d.batches[0] });
  d.subjects[0].facultyId = 'missing-faculty';
  const errors = CCValidation.validate(d);
  assert.ok(errors.some(x => x.message.includes('Duplicate ID')));
  assert.ok(errors.some(x => x.message.includes('existing lecture faculty')));
});

test('solver places every demo session without hard clashes', () => {
  const result = CCEngine.solve(structuredClone(CC_SAMPLES.demo), { seed: 7 });
  assert.equal(result.unallocated.length, 0, JSON.stringify(result.unallocated));
  const violations = CCEngine.audit(result.allocations, result.unallocated, CC_SAMPLES.demo);
  assert.equal(violations.filter(x => x.sev === 'error').length, 0, JSON.stringify(violations));
});

test('three-hour OS lab remains a single contiguous allocation', () => {
  const d = structuredClone(CC_SAMPLES.demo);
  const result = CCEngine.solve(d, { seed: 11 });
  const labs = result.allocations.filter(a => a.type === 'lab');
  assert.equal(labs.length, 2);
  assert.ok(labs.every(a => a.dur === 3));
  assert.ok(labs.every(a => a.start + a.dur <= 6));
});

test('Gini coefficient handles balanced and unequal workloads', () => {
  assert.equal(CCEngine.gini([4, 4, 4, 4]), 0);
  assert.ok(CCEngine.gini([0, 0, 0, 12]) > 0.7);
});
